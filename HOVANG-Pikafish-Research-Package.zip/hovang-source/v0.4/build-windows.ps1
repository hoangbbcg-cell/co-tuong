$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$gxx = Get-Command g++ -ErrorAction SilentlyContinue
if ($gxx) {
  $specArgs = @()
  $specPath = Join-Path $root "hovang-build-$PID.specs"
  Push-Location $root
  try {
    if ($gxx.Source -match '\s') {
      $specs = (& $gxx.Source -dumpspecs) -join "`n"
      $manifestSpec = '%{!shared:%:if-exists(default-manifest.o%s)}'
      if ($specs.Contains($manifestSpec)) {
        [IO.File]::WriteAllText($specPath, $specs.Replace($manifestSpec, ''), [Text.UTF8Encoding]::new($false))
        $specArgs = @("-specs=$specPath")
      }
    }
    & $gxx.Source @specArgs -O3 -std=c++17 -DNDEBUG -static -static-libgcc -static-libstdc++ -Wall -Wextra -o hovang-engine.exe engine.cpp
    if ($LASTEXITCODE -ne 0) { throw 'Biên dịch HOVANG Engine thất bại.' }
    & $gxx.Source @specArgs -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -Wall -Wextra -o hovang-tests.exe tests/test_engine.cpp
    if ($LASTEXITCODE -ne 0) { throw 'Biên dịch HOVANG tests thất bại.' }
  } finally { Remove-Item -LiteralPath $specPath -Force -ErrorAction SilentlyContinue; Pop-Location }
} else {
  $cl = Get-Command cl -ErrorAction SilentlyContinue
  if (-not $cl) { throw 'C++ compiler not found. Install MinGW-w64 g++ or use Visual Studio Developer PowerShell (MSVC).' }
  Push-Location $root
  try {
    & $cl.Source /nologo /O2 /EHsc /std:c++17 /DNDEBUG /MT /Fe:hovang-engine.exe engine.cpp
    if ($LASTEXITCODE -ne 0) { throw 'Biên dịch HOVANG Engine thất bại.' }
    & $cl.Source /nologo /O2 /EHsc /std:c++17 /MT /Fe:hovang-tests.exe tests/test_engine.cpp
    if ($LASTEXITCODE -ne 0) { throw 'Biên dịch HOVANG tests thất bại.' }
  } finally { Pop-Location }
}
& (Join-Path $root 'hovang-tests.exe')
if ($LASTEXITCODE -ne 0) { throw 'HOVANG native regression tests thất bại.' }
Write-Output 'Đã build HOVANG Engine v0.4 và chạy native tests.'

