# HOVANG Engine v0.4 — engine Cờ Tướng C++17 thử nghiệm

**Dùng trực tiếp để nâng cấp lựa chọn HOVANG v0.3 đã tích hợp trong game**; không thay Pikafish và không cần tạo nút mới.

Đây là engine tự xây bằng thuật toán và hàm đánh giá thủ công, không chứa mã nguồn hay weights NNUE Pikafish. Phiên bản này nâng cấp evaluation, tìm kiếm mate và một trường hợp tàn cuộc. **Chưa được chứng minh mạnh ngang Pikafish hoặc đủ an toàn để chạy production.**

## Những gì có sẵn

- Cờ Tướng cơ bản: sinh nước hợp lệ, king safety, flying generals, make/undo, FEN
- Iterative deepening, PVS/alpha-beta, Zobrist TT, aspiration, Null Move, LMR, killer/history, quiescence, check extension
- V0.4: Tốt qua sông, vị trí Mã/Xe/Pháo, king safety, mate-distance bounds, một số tàn cuộc bí nước
- UCCI/UCI-compatible commands cơ bản với `bestmove`, `info depth`, `perft`, `d`

## Biên dịch trên Windows (PowerShell, g++ đã cài)

Mở PowerShell tại thư mục giải nén chứa engine.cpp:

```powershell
g++ -O3 -std=c++17 -DNDEBUG -o hovang-engine.exe engine.cpp
g++ -O2 -std=c++17 -o hovang-tests.exe tests/test_engine.cpp
.\hovang-tests.exe
```

Kiểm tra engine thủ công:

```powershell
"ucci`nisready`nposition startpos`ngo depth 4 movetime 1000`nquit" | .\hovang-engine.exe
```

Bạn sẽ thấy `ucciok`, `readyok`, và `bestmove ...`. **Chưa đủ để xác nhận tích hợp game**; phải để Codex thay executable trong đúng đường dẫn backend hiện tại và chạy integration tests.

## Linux/WSL

```bash
g++ -O3 -std=c++17 -DNDEBUG -o hovang-engine engine.cpp
g++ -O2 -std=c++17 -o hovang-tests tests/test_engine.cpp
./hovang-tests
```

## Giao thức tương thích v0.3

```text
ucci
isready
setoption name Hash value 16
position startpos moves h7e7 h2e2
go movetime 1000 depth 10
quit
```

FEN là `position fen <board> <w|b> [moves ...]`, tọa độ cũ `a0..i9`: góc trái trên phía Đen, `w`=Đỏ, `b`=Đen. V0.4 không đổi protocol/tọa độ và không yêu cầu sửa adapter.

## Kết quả thử nghiệm

12 ván v0.4-v0.3, độ sâu 4 và giới hạn tính 80ms/nước: 6 thắng, 6 ván đánh dấu draw, 0 thua. Một số hòa là do hết giới hạn 110 ply; không được xem là hòa theo luật. Kết quả ban đầu, không phải bằng chứng Elo. Chi tiết: `tests/arena_v04_v03_depth4.txt`.

Bộ test xác nhận `perft(startpos,4)=3290240`, 14.417 thế cờ ngẫu nhiên và kiểm tra tàn cuộc bí nước. Các bài test chạy với g++ Linux; cần xác nhận lại trên máy Windows của bạn.

## Giới hạn và an toàn khi tích hợp

- `go` xử lý đồng bộ, không nhận `stop` giữa lúc nghĩ. Backend cần hard timeout/cancel/restart process.
- Không có NNUE, trained data, SMP; không có luật lặp chiếu dai/đuổi dai đầy đủ; repetition threefold = draw đơn giản.
- Nhiều người đồng thời phải được giới hạn số tiến trình, Hash, CPU/RAM từ backend, xác thực `bestmove` server-side.
- Game vẫn cần giữ đường rollback về v0.3/Pikafish.

## File trong bộ source

- `engine.cpp` — bản v0.4
- `engine-v0.3.cpp` — để so sánh/rollback
- `engine-v0.2.cpp` — baseline cũ
- `tests/test_engine.cpp` — kiểm thử C++
- `tests/arena.py` và `tests/arena_v04_v03_depth4.txt` — đấu thử
- `CODEX_INTEGRATION_PROMPT.md` — yêu cầu Codex cập nhật bản engine đã tích hợp
- `CHANGELOG.md` — thay đổi theo phiên bản
