# HOVANG Engine v0.4 — thay đổi so với v0.3

## Cải tiến giữ lại

- Evaluation: Tốt qua sông/khống chế trung lộ và phối hợp Tốt; Mã bị cản chân/outpost; Xe trên đường ít Tốt; độ thông thoáng của Pháo; an toàn Tướng xét Sĩ/Tượng và lực lượng đối phương.
- Mate-distance bounds trong alpha-beta giúp giới hạn cửa sổ các nước thắng/thua bằng chiếu bí.
- Quiescence bổ sung xử lý **hết nước hợp lệ nhưng không bị chiếu** (thua theo luật Cờ Tướng) cho một số tàn cuộc <=5 quân, thay vì nhầm với đánh giá tĩnh.
- Test regression mới cho tàn cuộc stalemate, đồng thời test Release không vô hiệu hóa assertions.

## Thử nghiệm và đánh giá trung thực

- Đã thử thêm cơ chế trừ điểm history đối với quiet moves không hiệu quả. Ở loạt 12 ván depth4 nó kém hơn cấu hình không trừ; **đã loại bỏ** thay đổi này.
- Đối đầu nhanh v0.4 với v0.3: depth 4, movetime 80ms (tối đa), 6 khai cuộc đổi màu, 12 ván, kết quả v0.4: 6 thắng / 6 trận ghi draw / 0 thua. Trong 6 draw: có những ván đạt giới hạn số ply, **không phải hòa chính thức**; do đó chưa đủ để xác định Elo.
- Loạt đối đầu depth5/movetime120ms không hoàn tất trong giới hạn thời gian thử nghiệm, **không tính** làm kết quả chính thức.
- Perft ban đầu depth4: 3,290,240 nhánh. 14,417 thế cờ được kiểm tra so sánh chiếu nhanh/chậm; make/undo và hash; UCCI test nước hợp lệ theo thời gian.
- Đã kiểm tra bằng g++ 14.2 Linux, không có bằng chứng build trên Windows tại đây. Cần Codex biên dịch và test bằng g++ trên máy bạn.

## Chưa có

- NNUE riêng, training, multithread search, luật chiếu dài/đuổi dài đầy đủ.
- UCCI `stop` bất đồng bộ; giữ watchdog của backend.
- Bộ đo Elo/SPRT đạt chuẩn; kết quả thi đấu còn rất ít.
