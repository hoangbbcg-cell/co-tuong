#!/usr/bin/env python3
"""Tiny reproducible smoke-match arena. NOT an Elo rating system."""
import argparse
import subprocess
import time
from collections import Counter

OPENINGS = [
    ['h7e7', 'h2e2'],
    ['b7e7', 'b2e2'],
    ['b9c7', 'b0c2'],
    ['h9g7', 'h0g2'],
    ['c9e7', 'c0e2'],
    ['a9a8', 'a0a1'],
]

class Engine:
    def __init__(self, exe):
        self.p = subprocess.Popen([exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  text=True, bufsize=1)
    def send(self, line):
        self.p.stdin.write(line+'\n');self.p.stdin.flush()
    def read_prefix(self, prefix):
        while True:
            line=self.p.stdout.readline().strip()
            if not line:
                if self.p.poll() is not None: raise RuntimeError('Engine exited')
                continue
            if line.startswith(prefix):return line
    def start(self):self.send('ucinewgame')
    def position(self, moves):self.send('position startpos'+(' moves '+' '.join(moves) if moves else ''))
    def go(self, depth, ms):
        self.send(f'go depth {depth} movetime {ms}')
        return self.read_prefix('bestmove ').split()[-1]
    def fen(self):
        self.send('d');return self.read_prefix('')
    def close(self):
        self.send('quit');self.p.communicate(timeout=3)

def match(old,new,opening,variant,depth,millis,max_plies):
    moves=opening[:];engines=[new,old] if variant==0 else [old,new]
    old.start();new.start()
    fen_counts=Counter()
    new.position(moves);fen_counts[new.fen()]+=1
    for step in range(len(moves),max_plies):
        side=step%2;playing=engines[side];playing.position(moves)
        chosen=playing.go(depth,millis)
        if chosen=='0000':
            return ('old' if playing is new else 'new'),'no_legal_moves',step
        if len(chosen)!=4:return ('old' if playing is new else 'new'),'invalid_notation',step
        moves.append(chosen)
        new.position(moves)
        fen=new.fen()
        # Illegal position rejected atomically: last position still has prior side-to-move.
        if not fen.endswith(' b' if (step+1)%2==1 else ' w'):
            return ('old' if playing is new else 'new'),'illegal_move',step
        fen_counts[fen]+=1
        if fen_counts[fen]>=3:return 'draw','threefold',step
    return 'draw','ply_limit',max_plies

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('old');ap.add_argument('new');ap.add_argument('--depth',type=int,default=3)
    ap.add_argument('--ms',type=int,default=500);ap.add_argument('--plies',type=int,default=100)
    ap.add_argument('--openings',type=int,default=6)
    args=ap.parse_args();old=Engine(args.old);new=Engine(args.new)
    results=Counter();start=time.monotonic()
    try:
        for num,opening in enumerate(OPENINGS[:args.openings]):
            for variant in (0,1):
                result,reason,ply=match(old,new,opening,variant,args.depth,args.ms,args.plies)
                results[result]+=1
                print(f'game {num*2+variant+1}: {result} / {reason} / ply {ply}',flush=True)
    finally:old.close();new.close()
    print('TOTAL:',dict(results),'elapsed=',round(time.monotonic()-start,1),'s')
