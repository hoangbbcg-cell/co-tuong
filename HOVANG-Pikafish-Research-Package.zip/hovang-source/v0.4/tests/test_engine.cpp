#ifdef NDEBUG
#undef NDEBUG // Keep regression assertions enabled for Release builds.
#endif
#define main original_engine_main
#include "../engine.cpp"
#undef main
#include <cassert>
#include <random>
#include <iostream>

int main(){
 initZobrist();
 Search e;
 assert(e.b.fen(START));
 assert(e.perft(0)==1);
 assert(e.perft(1)==44);
 assert(e.perft(2)==1920);
 assert(e.perft(3)==79666);
 assert(e.perft(4)==3290240ULL);

 // King-in-check optimized detector must agree with the slow reference.
 std::mt19937 rng(12345);
 int checkedPositions=0;
 for(int game=0;game<100;game++){
  Board x; assert(x.fen(START));
  for(int ply=0;ply<150;ply++){
   assert(x.checked(1)==x.checkedSlow(1));
   assert(x.checked(-1)==x.checkedSlow(-1));
   ++checkedPositions;
   auto ms=x.moves();
   if(ms.empty())break;
   Move m=ms[rng()%ms.size()];
   Board before=x;
   x.make(m);
   uint64_t hash=x.key;
   x.recalc();assert(x.key==hash);
   x.undo(m);
   assert(x.s==before.s&&x.side==before.side&&x.key==before.key);
   assert(x.kingSq[0]==before.kingSq[0]&&x.kingSq[1]==before.kingSq[1]);
   x.make(m);
  }
 }
 assert(checkedPositions>=10000);

 // Concrete rule situations: flying generals, cannon screen, horse leg.
 Board b;
 assert(b.fen("4k4/9/9/9/9/9/9/9/9/4K4 w"));
 assert(b.checked(1)&&b.checked(-1));
 assert(b.fen("4k4/9/4c4/9/9/9/9/4p4/9/4K4 w"));
 assert(b.checked(1));
 assert(b.fen("4k4/9/9/9/9/4P4/9/5n3/9/4K4 w"));
 assert(b.checked(1));
 assert(b.fen("4k4/9/9/9/9/4P4/9/5n3/5P3/4K4 w"));
 assert(!b.checked(1)); // horse leg blocked by red pawn f8

 // In Xiangqi having no legal move is a loss, even if the king is not in check.
 // Sparse stalemate must be recognized by quiescence, not scored as stand-pat.
 Board stuck;
 assert(stuck.fen("4k4/3R1R3/9/9/9/4P4/9/9/9/4K4 b"));
 assert(!stuck.checked(-1));
 assert(stuck.moves().empty());
 e.setPosition(stuck);
 e.deadline=chrono::steady_clock::now()+chrono::seconds(5);
 e.stopped=false;e.nodes=0;
 assert(e.qsearch(-INF,INF,0)==-MATE);
 // Counterexample: no capture available does not imply stalemate.
 assert(stuck.fen(START));
 assert(!stuck.moves().empty());
 e.setPosition(stuck);
 e.deadline=chrono::steady_clock::now()+chrono::seconds(5);
 e.stopped=false;e.nodes=0;
 assert(e.qsearch(-INF,INF,0)>-MATE);
 e.newGame();

 assert(!setPositionCmd(e,"position fen 9/9/9/9/9/9/9/9/9/9 w"));
 assert(e.b.fen()==string(START));
 assert(setPositionCmd(e,"position startpos moves h7e7"));
 assert(e.b.side==-1&&e.positions.size()==2);
 assert(!setPositionCmd(e,"position startpos moves h7e7 a0a9"));
 assert(e.positions.size()==2&&e.b.side==-1);
 assert(setPositionCmd(e,"position startpos"));
 auto legal=e.b.moves();
 Move chosen=e.think(250,8); // Must always return a valid move when time runs out.
 bool found=false;for(auto &m:legal)if(same(m,chosen))found=true;
 assert(found);
 cerr<<"PASS: stalemate in qsearch, perft depth4, "<<checkedPositions<<" random positions, make/undo/Zobrist, king attacks, FEN, atomic positions, timed search\n";
}
