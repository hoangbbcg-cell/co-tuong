// HOVANG Engine v0.4 - independent Xiangqi engine prototype, C++17.
// No Pikafish source code, trained networks, or weights are included.
// Coordinates are file a..i and rank 0..9, top (black) to bottom (red).
#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cstdint>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

constexpr int INF=32000, MATE=30000, MAX_PLY=96;
constexpr const char* START="rnbakabnr/9/1c5c1/p1p1p1p1p/9/9/P1P1P1P1P/1C5C1/9/RNBAKABNR w";
static uint64_t rngState=0x9E3779B97F4A7C15ULL;
static uint64_t rand64(){uint64_t z=(rngState+=0x9E3779B97F4A7C15ULL);z=(z^(z>>30))*0xBF58476D1CE4E5B9ULL;z=(z^(z>>27))*0x94D049BB133111EBULL;return z^(z>>31);}
static array<array<uint64_t,90>,14> zPiece;
static uint64_t zSide;
static int pindex(char p){const string pcs="KABNRCPkabnrcp";auto i=pcs.find(p);return i==string::npos?-1:int(i);}
static void initZobrist(){for(auto &a:zPiece)for(auto &v:a)v=rand64();zSide=rand64();}
static int value(char p){switch((char)tolower((unsigned char)p)){case 'k':return 20000;case 'r':return 950;case 'c':return 490;case 'n':return 440;case 'b':return 215;case 'a':return 205;case 'p':return 120;}return 0;}
struct Move {int a=-1,b=-1,order=0;char cap='.';};
static bool same(const Move&a,const Move&b){return a.a==b.a&&a.b==b.b;}
static string coord(int x){return string(1,char('a'+x%9))+to_string(x/9);}
static string notation(Move m){return m.a<0?"0000":coord(m.a)+coord(m.b);}
static int parseCoord(const string&s){if(s.size()!=2||s[0]<'a'||s[0]>'i'||s[1]<'0'||s[1]>'9')return -1;return 9*(s[1]-'0')+(s[0]-'a');}

struct Board {
 array<char,90> s{}; int side=1;uint64_t key=0; int kingSq[2]{-1,-1};
 Board(){s.fill('.');}
 static int color(char p){return p=='.'?0:(isupper((unsigned char)p)?1:-1);}
 static char type(char p){return (char)tolower((unsigned char)p);}
 static int pos(int r,int c){return r*9+c;}
 static int slot(int who){return who==1?1:0;}
 static bool inside(int r,int c){return r>=0&&r<10&&c>=0&&c<9;}
 static bool palace(int r,int c,int who){return c>=3&&c<=5&&(who==1?r>=7&&r<=9:r<=2&&r>=0);}
 static bool crossed(int r,int who){return who==1?r<=4:r>=5;}
 void recalc(){key=side==-1?zSide:0;for(int i=0;i<90;i++)if(s[i]!='.')key^=zPiece[pindex(s[i])][i];}
 bool fen(const string &str){
  Board tmp;istringstream in(str);string board,stm;if(!(in>>board))return false;
  if(!(in>>stm))stm="w";
  if(stm!="w"&&stm!="b")return false;
  int r=0,c=0;for(char ch:board){
   if(ch=='/'){if(c!=9||r>=9)return false;++r;c=0;continue;}
   if(ch>='1'&&ch<='9'){c+=ch-'0';if(c>9)return false;continue;}
   if(pindex(ch)<0||c>=9)return false;
   tmp.s[pos(r,c)]=ch; if(ch=='K')tmp.kingSq[1]=pos(r,c);if(ch=='k')tmp.kingSq[0]=pos(r,c);++c;
  }
  if(r!=9||c!=9)return false;
  tmp.side=stm=="b"?-1:1;
  int red=0,black=0;for(char x:tmp.s){if(x=='K')red++;if(x=='k')black++;}
  if(red!=1||black!=1)return false;
  tmp.recalc();*this=tmp;return true;
 }
 string fen()const{string f;for(int r=0;r<10;r++){int empt=0;for(int c=0;c<9;c++){char p=s[pos(r,c)];if(p=='.')empt++;else{if(empt)f+=to_string(empt);empt=0;f+=p;}}if(empt)f+=to_string(empt);if(r!=9)f+='/';}return f+(side==1?" w":" b");}
 bool attacks(int a,int b)const{
  char p=s[a];if(p=='.')return false;
  int who=color(p),r=a/9,c=a%9,R=b/9,C=b%9,dr=R-r,dc=C-c,ad=abs(dr),ac=abs(dc);
  switch(type(p)){
   case 'k': {
    if(ad+ac==1&&palace(R,C,who))return true;
    if(dc!=0||type(s[b])!='k'||color(s[b])!=-who)return false;
    int step=dr>0?9:-9;for(int x=a+step;x!=b;x+=step)if(s[x]!='.')return false;return true;
   }
   case 'a':return ad==1&&ac==1&&palace(R,C,who);
   case 'b':return ad==2&&ac==2&&(who==1?R>=5:R<=4)&&s[pos(r+dr/2,c+dc/2)]=='.';
   case 'n':if(ad==2&&ac==1)return s[pos(r+dr/2,c)]=='.';if(ad==1&&ac==2)return s[pos(r,c+dc/2)]=='.';return false;
   case 'r':case 'c':{
    if((dr&&dc)||(!dr&&!dc))return false;
    int step=dr?(dr>0?9:-9):(dc>0?1:-1),screens=0;
    for(int x=a+step;x!=b;x+=step)screens+=(s[x]!='.');
    return type(p)=='r'?screens==0:(s[b]=='.'?screens==0:screens==1);
   }
   case 'p':return (dc==0&&dr==-who)||(crossed(r,who)&&dr==0&&ac==1);
  }return false;
 }
 // Reference implementation retained for differential testing.
 bool checkedSlow(int who)const{
  int k=kingSq[slot(who)]; if(k<0)return true;
  for(int i=0;i<90;i++)if(color(s[i])==-who&&attacks(i,k))return true;
  return false;
 }
 // Fast direct king-attack detection: scan four rays, eight horse sources,
 // and immediate pawn / guard / elephant sources. Avoids scanning all 90 pieces.
 bool checked(int who)const{
  int k=kingSq[slot(who)];if(k<0)return true;
  const int r=k/9,c=k%9,enemy=-who;
  static constexpr int dirs[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
  for(const auto &d:dirs){
   int R=r+d[0],C=c+d[1],occupied=0;
   while(inside(R,C)){
    int i=pos(R,C);char x=s[i];
    if(x!='.'){
     ++occupied;
     if(color(x)==enemy){
      char t=type(x);
      if(occupied==1&&(t=='r'||(t=='k'&&attacks(i,k))||(t=='p'&&attacks(i,k))))return true;
      if(occupied==2&&t=='c')return true;
     }
     if(occupied>=2)break;
    }
    R+=d[0];C+=d[1];
   }
  }
  static constexpr int horses[8][2]={{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
  for(const auto &d:horses){int R=r+d[0],C=c+d[1];if(inside(R,C)){
   int i=pos(R,C);if(color(s[i])==enemy&&type(s[i])=='n'&&attacks(i,k))return true;
  }}
  static constexpr int diagonal[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};
  for(const auto &d:diagonal){
   int R=r+d[0],C=c+d[1];
   if(inside(R,C)){int i=pos(R,C);if(color(s[i])==enemy&&type(s[i])=='a'&&attacks(i,k))return true;}
   R=r+2*d[0];C=c+2*d[1];
   if(inside(R,C)){int i=pos(R,C);if(color(s[i])==enemy&&type(s[i])=='b'&&attacks(i,k))return true;}
  }
  return false;
 }
 void make(Move &m){
  char p=s[m.a];m.cap=s[m.b];
  key^=zPiece[pindex(p)][m.a]^zPiece[pindex(p)][m.b]^zSide;
  if(m.cap!='.')key^=zPiece[pindex(m.cap)][m.b];
  if(type(p)=='k')kingSq[slot(side)]=m.b;
  if(type(m.cap)=='k')kingSq[slot(-side)]=-1;
  s[m.b]=p;s[m.a]='.';side=-side;
 }
 void undo(const Move&m){
  side=-side;char p=s[m.b];s[m.a]=p;s[m.b]=m.cap;
  if(type(p)=='k')kingSq[slot(side)]=m.a;
  if(type(m.cap)=='k')kingSq[slot(-side)]=m.b;
  key^=zPiece[pindex(p)][m.a]^zPiece[pindex(p)][m.b]^zSide;
  if(m.cap!='.')key^=zPiece[pindex(m.cap)][m.b];
 }
 // A deliberately conservative legal move generator: slow but easier to verify.
 vector<Move> moves(bool captureOnly=false){
  vector<Move> out;out.reserve(captureOnly?16:48);int who=side;
  for(int a=0;a<90;a++)if(color(s[a])==who){
   int r=a/9,c=a%9;char t=type(s[a]);
   auto add=[&](int R,int C,bool knownAttack=false){
    if(!inside(R,C))return;
    int b=pos(R,C);
    if(color(s[b])==who||(captureOnly&&s[b]=='.'))return;
    if(!knownAttack&&!attacks(a,b))return;
    Move m{a,b,0,s[b]};make(m);bool ok=!checked(who);undo(m);if(ok)out.push_back(m);
   };
   static constexpr int kdir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
   static constexpr int diag[4][2]={{1,1},{-1,1},{1,-1},{-1,-1}};
   static constexpr int knight[8][2]={{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
   if(t=='k'){
    for(auto &d:kdir)add(r+d[0],c+d[1]);
    for(int R=0;R<10;R++)if(R!=r&&s[pos(R,c)]==(who==1?'k':'K'))add(R,c);
   }else if(t=='a'){for(auto &d:diag)add(r+d[0],c+d[1]);}
   else if(t=='b'){for(auto &d:diag)add(r+2*d[0],c+2*d[1]);}
   else if(t=='n'){for(auto &d:knight)add(r+d[0],c+d[1]);}
   else if(t=='p'){add(r-who,c,true);if(crossed(r,who)){add(r,c+1,true);add(r,c-1,true);}}
   else if(t=='r'||t=='c'){
    for(auto &d:kdir){int R=r+d[0],C=c+d[1],screen=0;
     while(inside(R,C)){
      int b=pos(R,C);
      if(t=='r'){
       if(color(s[b])!=who&&(!captureOnly||s[b]!='.'))add(R,C,true);
       if(s[b]!='.')break;
      }else{
       if(screen==0){if(s[b]=='.'){if(!captureOnly)add(R,C,true);}else screen=1;}
       else if(s[b]!='.'){if(color(s[b])==-who)add(R,C,true);break;}
      }
      R+=d[0];C+=d[1];
     }
    }
   }
  }return out;
 }
};

// HOVANG v0.4 position evaluator. Deliberately hand-crafted: no NNUE weights.
// Returns centipawns relative to side to move.
static int evaluate(const Board &b){
 int score=0,guards[2]{},pawnFile[2][9]{},heavy[2]{},advanced[2]{};
 for(int i=0;i<90;i++){
  char p=b.s[i];if(p=='.')continue;
  int who=Board::color(p),idx=Board::slot(who),r=i/9,c=i%9;
  char t=Board::type(p);
  if(t=='a'||t=='b')guards[idx]++;
  if(t=='p'){pawnFile[idx][c]++;if(Board::crossed(r,who))advanced[idx]++;}
  if(t=='r'||t=='c'||t=='n')heavy[idx]++;
 }
 for(int i=0;i<90;i++){
  char p=b.s[i];if(p=='.')continue;
  int who=Board::color(p),idx=Board::slot(who),r=i/9,c=i%9;
  int center=4-abs(c-4),adv=who==1?9-r:r;
  int v=value(p);
  switch(Board::type(p)){
   case 'p':{
    // After crossing the river a pawn controls an entire horizontal lane.
    bool crossed=Board::crossed(r,who);
    v+=adv*9+(crossed?55+center*9:center*2);
    if(adv>=7)v+=25;
    // Pawns on adjacent files help each other after crossing the river.
    if(crossed){
     int neighbor=0;
     for(int delta:{-1,1})if(c+delta>=0&&c+delta<9&&pawnFile[idx][c+delta]>0)neighbor++;
     v+=neighbor*11;
    }
    // A pawn at the back of an already blocked file has fewer useful options.
    int R=r-who;
    if(R>=0&&R<10&&b.s[9*R+c]!='.')v-=12;
    break;
   }
   case 'n':{
    v+=center*14+(4-abs(r-4))*7;
    int blocked=0;
    if(r>0&&b.s[i-9]!='.')blocked++;
    if(r<9&&b.s[i+9]!='.')blocked++;
    if(c>0&&b.s[i-1]!='.')blocked++;
    if(c<8&&b.s[i+1]!='.')blocked++;
    v-=blocked*24;
    // Knight outposts across the river are especially valuable with supporting pawns.
    if(Board::crossed(r,who))v+=17;
    break;
   }
   case 'r':{
    v+=center*8+(4-abs(r-4))*4;
    // A rook on an open file has more tactical and checking opportunities.
    if(pawnFile[idx][c]==0)v+=20;
    bool open=true;
    for(int R=0;R<10;R++)if(b.s[9*R+c]!='.'&&Board::type(b.s[9*R+c])=='p'){open=false;break;}
    if(open)v+=12;
    break;
   }
   case 'c':{
    v+=center*9+(4-abs(r-4))*5;
    // Cannon mobility before the first screen; avoid stranded cannons.
    int freeSquares=0;
    for(int delta:{-9,9,-1,1}){
     int x=i;
     while(true){
      int to=x+delta;
      if(to<0||to>=90||(abs(delta)==1&&to/9!=x/9)||b.s[to]!='.')break;
      ++freeSquares;x=to;
     }
    }
    v+=min(freeSquares,14)*3;
    break;
   }
   case 'a':case 'b':v+=6;break;
   case 'k':{
    v+=guards[idx]*14;
    // King shelter becomes vital against remaining rooks and cannons.
    int opponent=Board::slot(-who);
    v-=max(0,4-guards[idx])*(heavy[opponent]>=2?15:8);
    if(advanced[opponent]>=3&&guards[idx]<3)v-=14;
    break;
   }
  }
  score+=who*v;
 }
 return score*b.side+9;
}
struct TTEntry {uint64_t key=0;int16_t depth=-1,score=0;uint8_t flag=0,age=0;int8_t a=-1,b=-1;};
class Search {
 public:
 Board b;vector<TTEntry> tt;vector<uint64_t> positions;
 uint64_t nodes=0,qnodes=0;int history[90][90]{};Move killers[MAX_PLY][2]{};
 chrono::steady_clock::time_point deadline;bool stopped=false;uint8_t generation=0;
 size_t hashMb=32;
 Search(){setHash(32);b.fen(START);positions.push_back(b.key);}
 void setHash(size_t mb){hashMb=max(size_t(1),min(mb,size_t(256)));tt.assign(max(size_t(4096),hashMb*1024*1024/sizeof(TTEntry)),TTEntry{});}
 void clear(){fill(tt.begin(),tt.end(),TTEntry{});fill(&history[0][0],&history[0][0]+90*90,0);for(auto& pair:killers){pair[0]=Move{};pair[1]=Move{};}}
 void newGame(){b.fen(START);positions={b.key};clear();}
 void setPosition(const Board &other){b=other;positions={b.key};}
 bool apply(const string &str){
  if(str.size()!=4)return false;
  int a=parseCoord(str.substr(0,2)),c=parseCoord(str.substr(2,2));if(a<0||c<0)return false;
  auto ms=b.moves();for(auto &m:ms)if(m.a==a&&m.b==c){b.make(m);positions.push_back(b.key);return true;}return false;
 }
 bool timeout(){if((nodes&1023)==0&&chrono::steady_clock::now()>=deadline)stopped=true;return stopped;}
 bool repeated()const{int count=0;for(uint64_t k:positions)if(k==b.key&&++count>=3)return true;return false;}
 static int ttScore(int score,int ply){if(score>MATE-500)return score+ply;if(score<-MATE+500)return score-ply;return score;}
 static int fromTT(int score,int ply){if(score>MATE-500)return score-ply;if(score<-MATE+500)return score+ply;return score;}
 int moveOrder(const Move&m,const Move&ttm,int ply){
  if(ttm.a>=0&&same(m,ttm))return 3000000;
  if(m.cap!='.')return 1000000+value(m.cap)*20-value(b.s[m.a]);
  if(same(m,killers[ply][0]))return 900000;
  if(same(m,killers[ply][1]))return 890000;
  return history[m.a][m.b];
 }
 int qsearch(int alpha,int beta,int ply){
  ++nodes;++qnodes;if(timeout())return 0;
  if(repeated())return 0;
  bool check=b.checked(b.side);
  if(ply>=MAX_PLY-1)return evaluate(b);
  // In Xiangqi stalemate is a LOSS, even without check. Detect trapped kings
  // in sparse endgames before applying stand-pat cutoffs. In the middlegame,
  // the complete quiet-move generator here would be prohibitively expensive.
  int materialPieces=0;
  for(char p:b.s)materialPieces+=(p!='.');
  if(!check&&materialPieces<=5&&b.moves(false).empty())return -MATE+ply;
  int stand=evaluate(b);
  if(!check){if(stand>=beta)return stand;alpha=max(alpha,stand);}
  auto ms=b.moves(!check);
  if(ms.empty()&&check)return -MATE+ply;
  if(ms.empty()&&!check){ // Quiet legal moves may still exist; do not call it stalemate.
   return alpha;
  }
  for(auto &m:ms)m.order=(m.cap!='.'?value(m.cap)*10-value(b.s[m.a]):0);
  sort(ms.begin(),ms.end(),[](const Move&a,const Move&c){return a.order>c.order;});
  for(auto&m:ms){
   if(!check&&m.cap!='.'&&stand+value(m.cap)+210<alpha&&Board::type(m.cap)!='k')continue; // delta pruning
   b.make(m);positions.push_back(b.key);
   int sc=-qsearch(-beta,-alpha,ply+1);
   positions.pop_back();b.undo(m);
   if(stopped)return 0;
   if(sc>=beta)return sc;
   alpha=max(alpha,sc);
  }return alpha;
 }
 int search(int depth,int alpha,int beta,int ply,bool allowNull=true){
  ++nodes;if(timeout())return 0;
  if(repeated())return 0;
  if(ply>=MAX_PLY-1)return evaluate(b);
  bool inCheck=b.checked(b.side);
  if(depth<=0)return qsearch(alpha,beta,ply);
  // Mate-distance bounds: a closer mate is always preferable.
  alpha=max(alpha,-MATE+ply);
  beta=min(beta,MATE-ply-1);
  if(alpha>=beta)return alpha;
  // Check extensions: avoid tactical blindness when a king is under attack.
  if(inCheck&&depth<MAX_PLY-ply-2)depth++;
  const int oldAlpha=alpha;
  auto &slot=tt[b.key%tt.size()];TTEntry entry=slot;
  Move hashMove{entry.a,entry.b};
  if(entry.key!=b.key)hashMove=Move{};
  else if(entry.depth>=depth&&ply>0){
   int val=fromTT(entry.score,ply);
   if(entry.flag==0)return val;
   if(entry.flag==1&&val>=beta)return val;
   if(entry.flag==2&&val<=alpha)return val;
  }
  // Null move verification is disabled near low material and in check.
  int attackers=0;for(char p:b.s)if(Board::color(p)==b.side&&(Board::type(p)=='r'||Board::type(p)=='c'||Board::type(p)=='n'))attackers++;
  if(allowNull&&!inCheck&&depth>=4&&ply>0&&attackers>=2&&beta<MATE-1000){
   b.side=-b.side;b.key^=zSide;
   int sc=-search(depth-3,-beta,-beta+1,ply+1,false);
   b.side=-b.side;b.key^=zSide;
   if(stopped)return 0;
   if(sc>=beta)return sc;
  }
  auto ms=b.moves();
  if(ms.empty())return -MATE+ply; // Xiangqi no-legal-move (including stalemate) is a loss.
  for(auto &m:ms)m.order=moveOrder(m,hashMove,ply);
  sort(ms.begin(),ms.end(),[](const Move&a,const Move&c){return a.order>c.order;});
  int best=-INF,idx=0;Move bestMove=ms[0];
  for(auto &m:ms){
   b.make(m);positions.push_back(b.key);
   bool givesCheck=b.checked(b.side);
   int sc;
   if(idx==0)sc=-search(depth-1,-beta,-alpha,ply+1);
   else{
    int reduction=0;
    if(depth>=3&&idx>=4&&!inCheck&&!givesCheck&&m.cap=='.'&&ply>0){
     reduction=1+(depth>=6&&idx>=9);reduction=min(reduction,depth-2);
    }
    sc=-search(depth-1-reduction,-alpha-1,-alpha,ply+1);
    if(sc>alpha&&reduction)sc=-search(depth-1,-alpha-1,-alpha,ply+1);
    if(sc>alpha&&sc<beta)sc=-search(depth-1,-beta,-alpha,ply+1);
   }
   positions.pop_back();b.undo(m);
   if(stopped)return 0;
   if(sc>best){best=sc;bestMove=m;}
   alpha=max(alpha,sc);
   if(alpha>=beta){
    if(m.cap=='.'){
     int &h=history[m.a][m.b];h=min(800000,h+depth*depth*20);
     if(!same(killers[ply][0],m)){killers[ply][1]=killers[ply][0];killers[ply][0]=m;}
    }
    break;
   }
   ++idx;
  }
  if(slot.key!=b.key||slot.age!=generation||depth>=slot.depth){
   slot={b.key,(int16_t)depth,(int16_t)ttScore(best,ply),
         (uint8_t)(best<=oldAlpha?2:(best>=beta?1:0)),generation,
         (int8_t)bestMove.a,(int8_t)bestMove.b};
  }
  return best;
 }
 Move think(int ms,int maxDepth){
  auto startTime=chrono::steady_clock::now();
  deadline=startTime+chrono::milliseconds(max(ms,10));
  stopped=false;nodes=qnodes=0;++generation;
  auto root=b.moves();if(root.empty())return Move{};
  Move best=root.front();int lastScore=0;
  // Fail-soft aspiration: narrow window around previous iteration, re-search
  // with a full window if the score falls outside it. Never publish a partial iteration.
  for(int d=1;d<=maxDepth;d++){
   if(chrono::steady_clock::now()>=deadline)break;
   int low=(d>=4?max(-INF,lastScore-45):-INF);
   int high=(d>=4?min(INF,lastScore+45):INF);
   int bestScore=-INF; Move candidate=best;
   for(int attempt=0;attempt<2;attempt++){
    int alpha=low,beta=high;
    bestScore=-INF;candidate=best;
    for(auto &m:root)m.order=moveOrder(m,best,0);
    sort(root.begin(),root.end(),[](const Move &a,const Move &c){return a.order>c.order;});
    for(auto &m:root){
     b.make(m);positions.push_back(b.key);
     int sc=-search(d-1,-beta,-alpha,1);
     positions.pop_back();b.undo(m);
     if(stopped)break;
     if(sc>bestScore){bestScore=sc;candidate=m;}
     alpha=max(alpha,sc);
     if(alpha>=beta)break;
    }
    if(stopped)break;
    if((bestScore>low&&bestScore<high)||(low==-INF&&high==INF))break;
    low=-INF;high=INF;
   }
   if(stopped)break;
   best=candidate;lastScore=bestScore;
   auto elapsed=max<int64_t>(1,chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-startTime).count());
   cout<<"info depth "<<d<<" score cp "<<bestScore<<" nodes "<<nodes
       <<" time "<<elapsed<<" nps "<<(nodes*1000/elapsed)<<" pv "<<notation(best)<<'\n';
  }
  return best;
 }
 uint64_t perft(int depth){if(depth==0)return 1;uint64_t n=0;auto ms=b.moves();for(auto&m:ms){b.make(m);n+=perft(depth-1);b.undo(m);}return n;}
};

static bool setPositionCmd(Search &e, const string&line){
 istringstream in(line);string cmd,kind;in>>cmd>>kind;
 Board candidate;string token;
 if(kind=="startpos"){if(!candidate.fen(START))return false;}
 else if(kind=="fen"){
  string first,second;if(!(in>>first>>second)||!candidate.fen(first+" "+second))return false;
  // Skip optional halfmove/fullmove tokens (and other FEN suffixes) until 'moves'.
  while(in>>token){if(token=="moves")break;}
  if(token!="moves")token="";
 }else return false;
 vector<string> requested;
 if(kind=="startpos"){
  if(in>>token && token=="moves")while(in>>token)requested.push_back(token);
 }else if(token=="moves")while(in>>token)requested.push_back(token);
 // Atomic position update: a malformed command must never leave a partly-updated game.
 vector<uint64_t> newPositions{candidate.key};
 for(const string&moveStr:requested){
  if(moveStr.size()!=4)return false;
  int a=parseCoord(moveStr.substr(0,2)),b=parseCoord(moveStr.substr(2,2));
  if(a<0||b<0)return false;
  bool valid=false;auto ms=candidate.moves();
  for(auto &m:ms)if(m.a==a&&m.b==b){candidate.make(m);newPositions.push_back(candidate.key);valid=true;break;}
  if(!valid)return false;
 }
 e.b=candidate;e.positions=move(newPositions);
 return true;
}
int main(){
 ios::sync_with_stdio(false);cin.tie(nullptr);initZobrist();Search e;string line;
 while(getline(cin,line)){
  istringstream in(line);string cmd;in>>cmd;
  if(cmd=="uci"||cmd=="ucci"){
   cout<<"id name HOVANG Engine 0.4\nid author Independent engine prototype\n";
   cout<<"option name Hash type spin default 32 min 1 max 256\n";
   cout<<(cmd=="uci"?"uciok\n":"ucciok\n");
  }else if(cmd=="isready")cout<<"readyok\n";
  else if(cmd=="ucinewgame"||cmd=="newgame")e.newGame();
  else if(cmd=="setoption"){
   if(line.find("name Hash")!=string::npos){auto at=line.find("value ");if(at!=string::npos){try{e.setHash(stoul(line.substr(at+6)));}catch(...){cerr<<"Invalid Hash option\n";}}}
  }else if(cmd=="position"){
   if(!setPositionCmd(e,line))cerr<<"Invalid position or illegal move: "<<line<<'\n';
  }else if(cmd=="go"){
   string x;int ms=2000,depth=12;
   while(in>>x){if(x=="movetime")in>>ms;else if(x=="depth")in>>depth;}
   auto m=e.think(clamp(ms,10,600000),clamp(depth,1,32));
   cout<<"bestmove "<<notation(m)<<'\n';
  }else if(cmd=="perft"){
   int depth=0;in>>depth;
   if(depth>=0&&depth<=6)cout<<"perft "<<depth<<" nodes "<<e.perft(depth)<<'\n';
   else cerr<<"perft depth must be 0..6\n";
  }else if(cmd=="d")cout<<e.b.fen()<<'\n';
  else if(cmd=="quit")break;
  cout.flush();
 }
 return 0;
}
