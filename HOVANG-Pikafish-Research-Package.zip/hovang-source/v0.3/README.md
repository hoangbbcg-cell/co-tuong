# HOVANG Engine v0.3 — Xiangqi experimental engine

**Engine C++17 độc lập**, để thử nghiệm chơi cờ tướng trong backend Node.js. Không lấy source/model NNUE của Pikafish. **Không thể khẳng định mạnh ngang Pikafish**. Bản này tập trung vào tốc độ tìm kiếm và tính đúng đắn; chưa có NNUE/training, chưa đạt chuẩn production.

## Nâng cấp so với v0.2

- **Kiểm tra Tướng bị chiếu trực tiếp:** lưu vị trí 2 Tướng và quét các đường tấn công Xe/Pháo/Tướng, Mã, Tốt, Sĩ, Tượng. Tránh quét toàn bộ 90 ô rồi kiểm tra tấn công cho từng quân tại mỗi node.
- **Sinh nước đi hợp lệ nhanh hơn:** bỏ kiểm tra tấn công trùng lặp ở những nước Xe/Pháo/Tốt đã được xác định hợp lệ theo kiểu di chuyển.
- **Aspiration window tại root:** thử phạm vi điểm nhỏ quanh iteration trước, tìm kiếm lại toàn cửa sổ nếu thất bại. Khi quá giờ vẫn chọn nước đi của iteration đã hoàn tất.
- **Đánh giá quân bảo vệ Tướng nhanh hơn:** đếm trước Sĩ/Tượng thay vì quét 90 ô cho từng Tướng.
- **Thêm test:** 14.417 vị trí ngẫu nhiên so sánh phiên bản kiểm tra chiếu nhanh và chậm, đồng thời đối chiếu Zobrist/hoàn tác, luật khai cuộc/perft, một số thế chiếu Xe/Pháo/Mã/Tướng; test engine trả một nước hợp lệ khi có giới hạn thời gian.

Giữ lại từ v0.2: PVS/Alpha-Beta, Iterative Deepening, Zobrist TT, Null Move (có điều kiện), LMR, move ordering, killer/history, check extensions, quiescence, repetition cơ bản.

## Kết quả đo tại môi trường thử nghiệm

| Phép đo | v0.2 | v0.3 |
|---|---:|---:|
| Từ khai cuộc, `go depth 7 movetime 60000` | khoảng 1,69 giây | khoảng 0,84 giây |
| `perft(startpos, depth=4)` | 3.290.240 | 3.290.240 |

**Chỉ là một phép đo tốc độ trên cùng môi trường.** Tốc độ thay đổi theo CPU, compiler, FEN, cache, tải hệ thống và cách benchmark. Không có phép đo Elo đáng tin cậy.

Thử 8 ván `v0.3 vs v0.2`, depth=5, tối đa 60ms/nước và 70 ply: v0.3 thắng 2, v0.2 thắng 0, 6 ván bị **giới hạn số nước** (tạm đánh dấu hòa). Kết quả quá ít và nhiều ván chưa được phân định, **không thể kết luận mức tăng Elo**. Xem `tests/arena_v03_v02_depth5.txt`.

## Biên dịch

Linux / WSL (g++):

```bash
g++ -O3 -std=c++17 -DNDEBUG -o hovang-engine engine.cpp
g++ -O2 -std=c++17 -o hovang-tests tests/test_engine.cpp
./hovang-tests
```

Windows (g++ MinGW-w64):

```powershell
g++ -O3 -std=c++17 -DNDEBUG -o hovang-engine.exe engine.cpp
```

CMake (Linux/Windows):

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

Chỉ có source C++ trong ZIP; binary phải được biên dịch cho hệ điều hành/CPU cần chạy.

## Giao tiếp với backend

Dùng stdin/stdout; tọa độ `a0` là **góc trên trái** (bên Đen ban đầu), `i9` là **góc dưới phải** (bên Đỏ ban đầu).

```text
ucci
isready
setoption name Hash value 16
position startpos
position startpos moves h7e7 h2e2
go movetime 1000
quit
```

Hoặc `position fen <board> <w|b> [moves ...]`, `go depth 6 movetime 10000`, `perft 4`, `d`, `ucinewgame`.

Ví dụ output (tùy vị trí/thời gian):

```text
id name HOVANG Engine 0.3
...
info depth 5 score cp 0 nodes ... time ... nps ... pv h7h0
bestmove h7h0
```

**Giới hạn quan trọng:** `go` vẫn đồng bộ, chưa xử lý `stop` song song; backend phải có watchdog/hard timeout, hủy tiến trình nếu quá thời gian, xác thực mọi nước đi và quản lý queue/process riêng. Nhiều người chơi đồng thời = nhiều process được giới hạn CPU/RAM, không chia sẻ một process đang tính giữa các ván. Đây chưa phải UCI/UCCI đầy đủ; cần adapter FEN/toạ độ theo định dạng game.

## Phạm vi chưa hỗ trợ

- Không có NNUE hoặc model đã huấn luyện; chưa có đa luồng SMP trong một engine.
- Luật lặp **3 lần = hòa đơn giản** chưa thay thế luật chiếu dài/đuổi dài của cờ tướng; bản này không phù hợp để tự adjudicate giải đấu.
- Chưa hỗ trợ `stop`, ponder, `go infinite`, bàn cờ Cờ Úp, giới hạn CPU/RAM cấp hệ điều hành.
- Chưa chạy SPRT/Elo thực sự, chưa có đủ bộ tactic/regression nhiều thế cờ; không thay Pikafish production khi chưa test đủ.
- Bản hiện tại không đảm bảo sức mạnh chơi cờ cao trong mọi thế cờ.

## File trong ZIP

- `engine.cpp`: engine v0.3.
- `engine-v0.2.cpp`: baseline so sánh.
- `CMakeLists.txt`.
- `tests/test_engine.cpp`: correctness tests.
- `tests/arena.py`, `tests/arena_v03_v02_depth5.txt`: đấu đối chứng cơ bản.
- `CODEX_INTEGRATION_PROMPT.md`: giao Codex tích hợp dưới dạng tùy chọn thử nghiệm, **không phá Pikafish**.
- `CHANGELOG.md`.

## Thử đấu v0.2 với v0.3

```bash
g++ -O3 -std=c++17 -o hovang-old engine-v0.2.cpp
g++ -O3 -std=c++17 -o hovang-new engine.cpp
python3 tests/arena.py ./hovang-old ./hovang-new --depth 5 --ms 60 --plies 70 --openings 4
```

Nếu muốn đo Elo thực sự, phải tạo hệ thống adjudication chính xác, nhiều khai cuộc, giới hạn thời gian tương đương và số ván đủ lớn. **Không dùng hòa vì hết `plies` như một ván hòa đã được phân xử theo luật.**
