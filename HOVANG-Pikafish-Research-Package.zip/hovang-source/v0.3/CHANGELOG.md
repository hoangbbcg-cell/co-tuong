# Changelog

## v0.3 — tốc độ tìm kiếm + correctness (thử nghiệm)

- Cache vị trí 2 Tướng, cập nhật và phục hồi khi make/undo.
- Kiểm tra chiếu bằng hình học trực tiếp, giữ `checkedSlow` làm đối chứng.
- Giảm gọi kiểm tra di chuyển thừa khi đã biết hướng/quy tắc (Xe, Pháo, Tốt).
- Chỉ đếm Sĩ/Tượng bảo vệ Tướng một lần mỗi lần đánh giá.
- Aspiration window vòng iterative deepening; fail thì full-window, giữ kết quả completed depth.
- Thêm thông tin `time`, `nps` vào `info depth`.
- Mở rộng regression/perft/differential random 14.417 vị trí và timed move legality.
- Thử arena 8 ván với v0.2, kết quả thăm dò 2 thắng / 6 chạm giới hạn nước.

## v0.2 — nền search

- Incremental Zobrist, TT, mate-score conversion, table generations.
- Null-move pruning, late-move reductions, killer/history, check extensions.
- Basic positional evaluation, threefold draw approximation, atomic UCI position command.
- Perft, regression tests, simple arena.

## Chưa làm

- Engine-grade long check/chase adjudication, full asynchronous protocol/stop.
- Chính thức benchmark strength/Elo và multi-threading / NNUE riêng.
