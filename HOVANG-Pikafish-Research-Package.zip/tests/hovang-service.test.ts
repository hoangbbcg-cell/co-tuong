import { afterAll, describe, expect, it } from 'vitest'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { flipUciRanks, HovangError, HovangService } from '../server/services/hovangService'
import { toUci } from '../src/game/moves/uci'
import { applyMove, startGame } from '../src/game/moves/actions'
import { createGame } from '../src/game/state/initial'

const directory = mkdtempSync(join(tmpdir(), 'hovang-test-'))
const fakeEngine = join(directory, 'fake-engine.mjs')
writeFileSync(fakeEngine, `let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',chunk=>{input+=chunk;while(input.includes('go movetime ')){const [line,rest]=input.split(/go movetime \\d+\\n/);input=rest??'';const count=(line.match(/ moves /g)||[]).length;process.stdout.write('bestmove '+(count?'b0c2':'b9c7')+'\\n')}})`)
afterAll(() => rmSync(directory, { recursive: true, force: true }))

describe('HOVANG backend adapter', () => {
  it('converts game ranks to HOVANG ranks in both directions', () => {
    expect(flipUciRanks('b0c2')).toBe('b9c7')
    expect(flipUciRanks('b9c7')).toBe('b0c2')
    expect(flipUciRanks('bad')).toBe('')
  })
  it('gives a legal move for Red and Black using the shared game rules', async () => {
    const service = new HovangService(process.execPath, [fakeEngine])
    try {
      await service.ready()
      const red = await service.move({ moves: [], remainingMs: 15_000, level: 3 })
      expect(toUci(red)).toBe('b0c2')
      const start = startGame(createGame(0), 0)
      const afterRed = applyMove(start, red, 1)
      const black = await service.move({ moves: [toUci(red)], remainingMs: 15_000, level: 3 })
      expect(toUci(black)).toBe('b9c7')
      expect(afterRed.board[black.from.row]?.[black.from.col]?.side).toBe('black')
    } finally { service.close() }
  })

  it('rejects invalid levels and illegal engine responses', async () => {
    const badEngine = join(directory, 'bad-engine.mjs')
    writeFileSync(badEngine, `process.stdin.on('data',chunk=>{if(chunk.toString().includes('go movetime'))process.stdout.write('bestmove a0a9\\n')})`)
    const service = new HovangService(process.execPath, [badEngine])
    try {
      await expect(service.move({ moves: [], remainingMs: 15_000, level: 0 })).rejects.toMatchObject({ status: 400 })
      await expect(service.move({ moves: [], remainingMs: 15_000, level: 3 })).rejects.toBeInstanceOf(HovangError)
    } finally { service.close() }
  })
})
