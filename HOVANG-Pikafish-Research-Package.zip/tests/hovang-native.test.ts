import { afterEach, expect, it } from 'vitest'
import { createApplication } from '../server/app'
import { applyMove, finishGame, startGame } from '../src/game/moves/actions'
import { createGame } from '../src/game/state/initial'
import { opposite } from '../src/game/state/initial'
import { toUci } from '../src/game/moves/uci'

const app = createApplication()
afterEach(async () => { await app.close() })

const nativeTest = process.env.RUN_HOVANG_NATIVE_TESTS === '1' ? it : it.skip

nativeTest('native HOVANG HTTP integration: both sides and game completion', async () => {
  await new Promise<void>(resolve => app.http.listen(0, '127.0.0.1', resolve))
  const port = (app.http.address() as { port: number }).port
  const base = `http://127.0.0.1:${port}/api/hovang`
  const ready = await fetch(`${base}/ready`)
  expect(ready.status).toBe(200)
  const requestMove = async (moves: string[]) => {
    const response = await fetch(`${base}/move`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ moves, remainingMs: 600_000, level: 1 }),
    })
    const body = await response.json() as { move?: ReturnType<typeof JSON.parse>; error?: string }
    if (!response.ok || !body.move) throw new Error(`HOVANG ${response.status}: ${body.error ?? 'missing move'}`)
    return body.move as { from: { row: number; col: number }; to: { row: number; col: number } }
  }
  let game = startGame(createGame(0), 0)
  const moves: string[] = []
  for (let ply = 0; ply < 240; ply++) {
    const move = await requestMove(moves)
    const side = game.currentTurn
    const next = applyMove(game, move, ply + 1)
    expect(next.board).not.toBe(game.board)
    moves.push(toUci(move))
    game = next
    if (ply === 0) expect(side).toBe('red')
    if (ply === 1) expect(side).toBe('black')
    if (game.phase === 'finished') break
  }
  if (game.phase === 'playing') game = finishGame(game, opposite(game.currentTurn), 'resign')
  expect(game.phase).toBe('finished')
  expect(game.result?.reason).toMatch(/checkmate|stalemate|resign/)
}, 180_000)
