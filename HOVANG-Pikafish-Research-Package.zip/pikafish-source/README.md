# Pikafish source was not found in this checkout

The project contains release binaries, release documentation, and the release `.7z` package, but no Pikafish `.cpp`, `.h`, or `.hpp` source files. The package listing was inspected and contains binaries, NNUE, license files, README/wiki documentation, and contributor metadata, not the engine source tree.

The README identifies the source tag as `Pikafish-2026-09-06`:
https://github.com/official-pikafish/Pikafish/tree/Pikafish-2026-09-06

No source was downloaded or included. The exact commit SHA is not recorded in the project.
