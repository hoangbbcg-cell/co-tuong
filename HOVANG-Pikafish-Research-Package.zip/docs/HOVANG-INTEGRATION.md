# HOVANG Engine v0.4

HOVANG v0.4 là engine C++17 thử nghiệm trong chế độ Chơi Với Máy. Lựa chọn HOVANG dùng chung ComputerPage/GamePage, gameplay và backend adapter hiện có. Pikafish và Máy · Cơ bản giữ nguyên. HOVANG không hỗ trợ Cờ Úp.

## Build native engine

Trên Windows, cài MinGW-w64 `g++` hoặc dùng Developer PowerShell for Visual Studio có `cl`, rồi từ `board-game/` chạy:

```powershell
powershell -ExecutionPolicy Bypass -File engines/hovang-v0.4/build-windows.ps1
```

Script build C++17 Release cho engine và tests, sau đó chạy toàn bộ native regressions trước khi dùng. Linux/WSL:

```sh
cd engines/hovang-v0.4
g++ -O3 -std=c++17 -DNDEBUG -o hovang-engine engine.cpp
g++ -O2 -std=c++17 -o hovang-tests tests/test_engine.cpp
./hovang-tests
```

Có thể đặt `HOVANG_PATH` để backend dùng executable build riêng. Binary Windows mặc định là `engines/hovang-v0.4/hovang-engine.exe`; binary không commit. Bản v0.3 vẫn ở `engines/hovang-v0.3/` để rollback: đổi default path trong `server/services/hovangService.ts` về v0.3 và build/test lại.

Script Windows liên kết tĩnh GCC runtime để executable không cần DLL MinGW bên cạnh. Với WinLibs trong đường dẫn có dấu cách, script tạm bỏ entry default-manifest khỏi GCC specs để tránh lỗi linker; file specs tạm được xóa sau build.

Chạy backend integration test qua native executable trên Windows PowerShell:

```powershell
$env:RUN_HOVANG_NATIVE_TESTS = '1'
npm.cmd test -- tests/hovang-native.test.ts
Remove-Item Env:RUN_HOVANG_NATIVE_TESTS
```

## Runtime

`POST /api/hovang/move` nhận lịch sử UCI và FEN ban đầu theo hợp đồng adapter hiện tại. Backend dựng lại và kiểm tra từng nước, chuyển tọa độ giữa game và HOVANG, rồi xác thực nước trả về và repetition trước khi gửi cho client. Mỗi yêu cầu chạy process riêng; tối đa 2 process đồng thời, Hash 16 MB, thời gian nghĩ theo cấp 1–10 và watchdog 6 giây ngoài movetime. Hủy request sẽ dừng process. Giữ các giới hạn này vì `go` của HOVANG xử lý đồng bộ và không nhận `stop` khi đang nghĩ.

## Giới hạn

HOVANG v0.4 không có NNUE, dữ liệu huấn luyện hoặc tìm kiếm đa luồng; chưa có luật chiếu dai/đuổi dai đầy đủ và chưa có Elo/SPRT đáng tin cậy. Đây là engine thử nghiệm, không thay Pikafish và chưa được đánh giá phù hợp production.
