# Binary inclusion note

This package includes only the HOVANG v0.4 Windows x64 executable. Pikafish Windows/Linux executables and the original 7z release archive remain in the project and are identified by path, size, and SHA-256 in `FILE_MANIFEST.md`; they are not copied here. The corresponding Pikafish source is absent, and the archive includes the separately licensed NNUE file. This avoids conveying a GPL engine binary without the corresponding source and avoids placing the NNUE model in this research package.
