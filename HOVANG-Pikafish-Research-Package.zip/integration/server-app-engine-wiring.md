# Engine wiring excerpt

Source: `board-game/server/app.ts`. This excerpt records only the engine-specific dependency wiring; the rest of the app is omitted.

```ts
import { PikafishService } from './services/pikafishService'
import { pikafishRouter } from './controllers/pikafishController'
import { HovangService } from './services/hovangService'
import { hovangRouter } from './controllers/hovangController'

const pikafish = new PikafishService()
const hovang = new HovangService()
app.use('/api/pikafish', pikafishRouter(pikafish))
app.use('/api/hovang', hovangRouter(hovang))
// On HTTP server close: pikafish.close(); hovang.close().
```
