import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process'
import { existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { createGame } from '../../src/game/state/initial'
import { gameFromPositionFen } from '../../src/game/state/customPosition'
import { applyMove, startGame } from '../../src/game/moves/actions'
import { fromUci } from '../../src/game/moves/uci'
import { candidateRepetition } from '../../src/game/rules/repetition'
import { isMoveLegal } from '../../src/game/rules'
import type { Move } from '../../src/types/game'

export class HovangError extends Error {
  constructor(message: string, readonly status = 503) { super(message) }
}

const defaultBinary = fileURLToPath(new URL('../../engines/hovang-v0.4/hovang-engine' + (process.platform === 'win32' ? '.exe' : ''), import.meta.url))
const thinkTimes = [120, 180, 250, 350, 500, 700, 950, 1250, 1700, 2200]
// The game UCI ranks count from Red's baseline; HOVANG coordinates count from Black's baseline.
export function flipUciRanks(move: string): string {
  if (!/^[a-i][0-9][a-i][0-9]$/.test(move)) return ''
  return `${move[0]}${9 - Number(move[1])}${move[2]}${9 - Number(move[3])}`
}

export class HovangService {
  private readonly children = new Set<ChildProcessWithoutNullStreams>()
  constructor(private readonly binary = process.env.HOVANG_PATH || defaultBinary, private readonly binaryArgs: string[] = []) {}

  close() { for (const child of this.children) child.kill() }

  async ready(signal?: AbortSignal) {
    const move = await this.run('position startpos', 80, signal)
    const candidate = move ? fromUci(flipUciRanks(move)) : null
    const game = startGame(createGame(0), 0)
    if (!candidate || game.board[candidate.from.row]?.[candidate.from.col]?.side !== 'red' || !isMoveLegal(candidate.from.row, candidate.from.col, candidate.to.row, candidate.to.col, game.board)) throw new HovangError('HOVANG không trả về nước khởi động hợp lệ.')
  }

  async move(input: unknown, signal?: AbortSignal): Promise<Move> {
    if (!input || typeof input !== 'object' || !('moves' in input) || !Array.isArray(input.moves) || input.moves.length > 500 || !('remainingMs' in input) || typeof input.remainingMs !== 'number' || !Number.isFinite(input.remainingMs) || input.remainingMs <= 0 || input.remainingMs > 1800000) throw new HovangError('Dữ liệu ván đấu không hợp lệ (tối đa 500 nước).', 400)
    const level = 'level' in input ? input.level : 5
    if (typeof level !== 'number' || !Number.isInteger(level) || level < 1 || level > 10) throw new HovangError('Cấp độ máy không hợp lệ.', 400)
    let game = createGame(0)
    let prefix = 'position startpos'
    if ('initialFen' in input) {
      try {
        game = gameFromPositionFen(input.initialFen)
        prefix = `position fen ${input.initialFen}`
      } catch (error) { throw new HovangError(error instanceof Error ? error.message : 'Thế cờ không hợp lệ.', 400) }
    }
    game = startGame(game, 0)
    const history: string[] = []
    for (const token of input.moves) {
      const move = typeof token === 'string' ? fromUci(token) : null
      if (!move || game.phase !== 'playing') throw new HovangError('Lịch sử nước đi không hợp lệ.', 400)
      const next = applyMove(game, move, 0)
      if (next.board === game.board) throw new HovangError('Lịch sử có nước đi sai luật.', 400)
      history.push(token)
      game = next
    }
    if (game.phase !== 'playing') throw new HovangError('Ván đấu đã kết thúc.', 400)
    const movetime = Math.max(30, Math.min(thinkTimes[level - 1]!, input.remainingMs - 150, 4000))
    const engineHistory = history.map(flipUciRanks)
    if (engineHistory.some(move => !move)) throw new HovangError('Không đổi được tọa độ lịch sử cho HOVANG.', 400)
    const command = `${prefix}${engineHistory.length ? ` moves ${engineHistory.join(' ')}` : ''}`
    const result = await this.run(command, movetime, signal)
    const move = result ? fromUci(flipUciRanks(result)) : null
    if (!move || game.board[move.from.row]?.[move.from.col]?.side !== game.currentTurn || !isMoveLegal(move.from.row, move.from.col, move.to.row, move.to.col, game.board)) throw new HovangError('HOVANG trả về nước đi không hợp lệ.')
    if (candidateRepetition(game, move).forbidden) throw new HovangError('HOVANG trả về nước đi lặp bị cấm.')
    return move
  }

  private run(position: string, movetime: number, signal?: AbortSignal): Promise<string> {
    if (signal?.aborted) return Promise.reject(new HovangError('Đã hủy lượt HOVANG.', 499))
    if (!existsSync(this.binary)) return Promise.reject(new HovangError('Chưa biên dịch HOVANG. Xem engines/hovang-v0.4/README.md.'))
    if (this.children.size >= 2) return Promise.reject(new HovangError('HOVANG đang bận. Vui lòng thử lại.', 429))
    return new Promise((resolve, reject) => {
      const child = spawn(this.binary, this.binaryArgs, { cwd: fileURLToPath(new URL('../../engines/hovang-v0.4/', import.meta.url)), windowsHide: true, shell: false, stdio: ['pipe', 'pipe', 'pipe'] })
      this.children.add(child)
      let settled = false
      let buffer = ''
      const finish = (error?: Error, bestmove = '') => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        signal?.removeEventListener('abort', cancel)
        child.kill()
        this.children.delete(child)
        if (error) reject(error)
        else resolve(bestmove)
      }
      const cancel = () => finish(new HovangError('Đã hủy lượt HOVANG.', 499))
      const timer = setTimeout(() => finish(new HovangError('HOVANG vượt quá thời gian cho phép.')), movetime + 6000)
      signal?.addEventListener('abort', cancel, { once: true })
      child.stdout.on('data', (chunk: Buffer) => {
        buffer += chunk.toString('utf8')
        const lines = buffer.split(/\r?\n/)
        buffer = lines.pop() ?? ''
        for (const line of lines) if (line.startsWith('bestmove ')) finish(undefined, line.trim().split(/\s+/)[1] ?? '')
      })
      child.stderr.resume()
      child.once('error', () => finish(new HovangError('Không khởi động được HOVANG. Kiểm tra bản biên dịch.')))
      child.once('close', () => finish(new HovangError('HOVANG dừng đột ngột.')))
      child.stdin.once('error', () => finish(new HovangError('Mất kết nối với tiến trình HOVANG.')))
      child.stdin.write(`ucci\nisready\nsetoption name Hash value 16\n${position}\ngo movetime ${Math.floor(movetime)}\n`)
    })
  }
}
