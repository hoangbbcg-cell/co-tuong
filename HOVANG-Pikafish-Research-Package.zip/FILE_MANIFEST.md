# File manifest

Package assembled from the local project checkout on 2026-10-24 (Asia/Bangkok). The table lists every regular file in this ZIP, its origin, and the identified version. No `.env`, credentials, account data, database dump, `node_modules`, `.git`, build logs, Pikafish NNUE, Pikafish release archive, or Pikafish executable is included.

## Pikafish inventory (not copied as source/binaries)

| Local file | Bytes | SHA-256 | Origin/version | Package status |
|---|---:|---|---|---|
| `board-game/engines/pikafish/Pikafish-Windows-x86-64-universal.exe` | 6,944,256 | `0D57D64C212E78F96CBA9E5E4F140D8872F8FAA42EA631A27AB6C5DB08509DA3` | Local release binary; docs/UCI identify 2026-09-06 | Excluded: matching source absent; GPL source provision cannot be included |
| `board-game/engines/pikafish/pikafish` | 6,875,464 | `727828293830DE8082A80B224BF47B32700C2D1A441908EA11B3C9197178C20C` | Local Linux release binary | Excluded for same source/license reason |
| `board-game/engines/pikafish/Pikafish.2026-09-06.7z` | 53,603,424 | `41952BBFE2520FACEB5902C69E6AB4845CC999841D2B49A95CC1BE7867A25E5B` | Release package; hash matches README; archive contains binaries/docs/NNUE but no C++ source | Excluded: contains NNUE; source absent |
| `board-game/engines/pikafish/pikafish.nnue` | 50,706,378 | `7D13D73569A9B571BA0EB20CF1596247BC2A42738967E61AFEF6482B231E900E` | Model paired with local release; separate `NNUE-License.md` | Excluded; path, size, checksum provided for user's decision |

The project README identifies upstream source/release tag `Pikafish-2026-09-06`; no exact commit SHA is recorded. No Pikafish `.cpp`, `.h`, or `.hpp` files were found in the local engine folder or release archive. No source was downloaded.

## Included files

| Package path | Origin | Version / notes |
|---|---|---|
| `FILE_MANIFEST.md` | Created from package inventory | This manifest |
| `PIKAFISH_HOVANG_ANALYSIS.md` | Created from verified source/config/docs inventory | Analysis with limitations and license notes |
| `pikafish-source/README.md` | Created from local inventory and release archive listing | Pikafish source absent; source URL/tag recorded; no download |
| `engine-binaries/README.md` | Created for this package | Explains binary inclusion/license decision |
| `engine-binaries/hovang-v0.4-windows-x64.exe` | `board-game/engines/hovang-v0.4/hovang-engine.exe` | HOVANG v0.4; 3,020,343 bytes; SHA-256 `19FB7BCC051ED1B7A898FBBDC75B8B6F7989D57A3ADBB136BD7C84F88151A3A2` |
| `docs/HOVANG-INTEGRATION.md` | `board-game/docs/HOVANG-INTEGRATION.md` | Current v0.4 backend integration/runtime docs |
| `docs/pikafish/AUTHORS` | `board-game/engines/pikafish/AUTHORS` | Pikafish release authors/contributors notice |
| `docs/pikafish/Copying.txt` | `board-game/engines/pikafish/Copying.txt` | GPL-3.0 license text, copied unchanged |
| `docs/pikafish/NNUE-License.md` | `board-game/engines/pikafish/NNUE-License.md` | Separate NNUE license, copied unchanged; weights omitted |
| `docs/pikafish/README.md` | `board-game/engines/pikafish/README.md` | Release/source tag, setup and documented limits |
| `docs/pikafish/uci-options.txt` | `board-game/engines/pikafish/uci-options.txt` | Captured UCI identity/options for Pikafish 2026-09-06 |
| `hovang-source/v0.3/CHANGELOG.md` | `board-game/engines/hovang-v0.3/CHANGELOG.md` | HOVANG v0.3 history |
| `hovang-source/v0.3/engine.cpp` | `board-game/engines/hovang-v0.3/engine.cpp` | HOVANG v0.3 comparison/rollback source |
| `hovang-source/v0.3/README.md` | `board-game/engines/hovang-v0.3/README.md` | HOVANG v0.3 integration/build notes |
| `hovang-source/v0.3/tests/test_engine.cpp` | `board-game/engines/hovang-v0.3/tests/test_engine.cpp` | Native C++ tests |
| `hovang-source/v0.4/CHANGELOG.md` | `board-game/engines/hovang-v0.4/CHANGELOG.md` | HOVANG v0.4 changes and measured limitations |
| `hovang-source/v0.4/CMakeLists.txt` | `board-game/engines/hovang-v0.4/CMakeLists.txt` | C++17 targets/tests |
| `hovang-source/v0.4/README.md` | `board-game/engines/hovang-v0.4/README.md` | Protocol, search features, build and limitations |
| `hovang-source/v0.4/build-windows.ps1` | `board-game/engines/hovang-v0.4/build-windows.ps1` | Local Windows build/test script |
| `hovang-source/v0.4/engine.cpp` | `board-game/engines/hovang-v0.4/engine.cpp` | Current engine source, v0.4 |
| `hovang-source/v0.4/tests/arena.py` | `board-game/engines/hovang-v0.4/tests/arena.py` | Arena harness source; not run for this package task |
| `hovang-source/v0.4/tests/arena_v04_v03_depth4.txt` | Same project path | 12-game low-budget record; not an Elo result |
| `hovang-source/v0.4/tests/arena_v04_v03_depth5.txt` | Same project path | Incomplete exploratory run, not a result claim |
| `hovang-source/v0.4/tests/test_engine.cpp` | `board-game/engines/hovang-v0.4/tests/test_engine.cpp` | Native regression tests |
| `integration/client/hooks/useComputer.ts` | `board-game/src/features/game/hooks/useComputer.ts` | Sends history/clock/level/FEN to selected engine |
| `integration/client/hooks/useComputerSetup.ts` | `board-game/src/features/lobby/hooks/useComputerSetup.ts` | Selection and readiness flow |
| `integration/client/services/hovang.ts` | `board-game/src/services/hovang.ts` | HOVANG Axios adapter |
| `integration/client/services/pikafish.ts` | `board-game/src/services/pikafish.ts` | Pikafish Axios adapter |
| `integration/server-app-engine-wiring.md` | Narrow excerpt from `board-game/server/app.ts` | Engine services/routes/shutdown wiring; unrelated app omitted |
| `integration/server/controllers/hovangController.ts` | `board-game/server/controllers/hovangController.ts` | HOVANG HTTP endpoint/cancel handling |
| `integration/server/controllers/pikafishController.ts` | `board-game/server/controllers/pikafishController.ts` | Pikafish HTTP endpoint/cancel handling |
| `integration/server/services/hovangService.ts` | `board-game/server/services/hovangService.ts` | UCCI process, coordinates, time/hash/caps, legal-move validation |
| `integration/server/services/pikafishCandidates.ts` | `board-game/server/services/pikafishCandidates.ts` | MultiPV candidate filtering and selection |
| `integration/server/services/pikafishLevels.ts` | `board-game/server/services/pikafishLevels.ts` | Search/Threads/Hash levels and UCI option clamp |
| `integration/server/services/pikafishService.ts` | `board-game/server/services/pikafishService.ts` | UCI process, clock, cancellation, candidate and legal-move validation |
| `tests/hovang-native.test.ts` | `board-game/tests/hovang-native.test.ts` | Gated real-engine HTTP integration/self-play test |
| `tests/hovang-service.test.ts` | `board-game/tests/hovang-service.test.ts` | HOVANG adapter coordinate/error tests |
| `tests/pikafish-candidates.test.ts` | `board-game/tests/pikafish-candidates.test.ts` | Candidate filtering/selection tests |
| `tests/pikafish-levels.test.ts` | `board-game/tests/pikafish-levels.test.ts` | UCI limits/options/profile tests |
| `tests/pikafish.test.ts` | `board-game/tests/pikafish.test.ts` | Service/API tests and gated real-engine test |